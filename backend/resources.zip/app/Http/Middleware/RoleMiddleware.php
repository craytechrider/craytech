<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(
        Request $request,
        Closure $next,
        $role
    ): Response {

        /*
        |--------------------------------------------------------------------------
        | CHECK AUTHENTICATION
        |--------------------------------------------------------------------------
        */

        $user = $request->user();

        if (!$user) {

            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated.',
            ], 401);
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK ROLE
        |--------------------------------------------------------------------------
        */

        if ($user->role !== $role) {

            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK ACTIVE ACCOUNT
        |--------------------------------------------------------------------------
        |
        | This is especially important for delivery
        | personnel.
        |
        */

        if (
            isset($user->is_active)
            &&
            !$user->is_active
        ) {

            return response()->json([
                'success' => false,
                'message' =>
                'Your account has been disabled.',
            ], 403);
        }


        /*
        |--------------------------------------------------------------------------
        | AUTHORIZED
        |--------------------------------------------------------------------------
        */

        return $next($request);
    }
}

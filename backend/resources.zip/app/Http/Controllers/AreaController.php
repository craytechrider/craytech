<?php

namespace App\Http\Controllers;

use App\Models\Area;
use App\Models\AreaType;
use App\Models\CrayfishType;
use Illuminate\Http\Request;

class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $areas = Area::with(['areaType', 'crayfishType'])->get();
        $areaTypes = AreaType::all();
        $crayfishTypes = CrayfishType::all();

        return view('admin.farm-management', compact(
            'areas',
            'areaTypes',
            'crayfishTypes'
        ));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'area_type_id' => 'required|exists:area_types,id',
            'capacity' => 'required|integer|min:1',
            'occupied' => 'required|boolean',
            'crayfish_type_id' => 'nullable|exists:crayfish_types,id',
            'total_crayfish' => 'nullable|integer|min:0'
        ]);

        // If the area is available, clear crayfish info
        if (!$validated['occupied']) {
            $validated['crayfish_type_id'] = null;
            $validated['total_crayfish'] = 0;
        }

        Area::create($validated);

        return redirect()
            ->route('farm-management')
            ->with('success', 'Area added successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Area $area)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Area $area)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Area $area)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'area_type_id' => 'required|exists:area_types,id',
            'capacity' => 'required|integer|min:1',
            'occupied' => 'required|boolean',
            'crayfish_type_id' => 'nullable|exists:crayfish_types,id',
            'total_crayfish' => 'nullable|integer|min:0',
        ]);

        if (!$validated['occupied']) {
            $validated['crayfish_type_id'] = null;
            $validated['total_crayfish'] = 0;
        }

        $area->update($validated);

        return redirect()
            ->route('farm-management')
            ->with('success', 'Area updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Area $area)
    {
        //
    }
}

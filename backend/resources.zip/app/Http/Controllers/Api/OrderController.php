<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\DeliveryAddress;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | GET ORDERS
    |--------------------------------------------------------------------------
    |
    | ADMIN:
    |   Can see all orders.
    |
    | CUSTOMER:
    |   Can only see their own orders.
    |
    | DELIVERY:
    |   Can only see orders assigned to their account.
    |
    */

    public function index(Request $request)
    {
        try {

            $user = $request->user();

            /*
            |--------------------------------------------------------------------------
            | ADMIN
            |--------------------------------------------------------------------------
            */

            if ($user->role === 'admin') {

                $orders = Order::with([
                    'items.product',
                    'user',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ])
                    ->latest()
                    ->get();
            }

            /*
            |--------------------------------------------------------------------------
            | DELIVERY PERSONNEL
            |--------------------------------------------------------------------------
            */ elseif ($user->role === 'delivery') {

                $orders = Order::with([
                    'items.product',
                    'user',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ])
                    ->where(
                        'delivery_personnel_id',
                        $user->id
                    )
                    ->where(
                        'delivery_method',
                        'delivery'
                    )
                    ->whereNotIn(
                        'delivery_status',
                        [
                            'delivered',
                        ]
                    )
                    ->latest()
                    ->get();
            }

            /*
            |--------------------------------------------------------------------------
            | CUSTOMER
            |--------------------------------------------------------------------------
            */ else {

                $orders = Order::with([
                    'items.product',
                    'user',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ])
                    ->where(
                        'user_id',
                        $user->id
                    )
                    ->latest()
                    ->get();
            }

            return response()->json([
                'success' => true,
                'data' => $orders,
            ]);
        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Failed to load orders.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SHOW ORDER
    |--------------------------------------------------------------------------
    */

    public function show(
        Request $request,
        Order $order
    ) {
        try {

            $user = $request->user();

            /*
            |--------------------------------------------------------------------------
            | ADMIN
            |--------------------------------------------------------------------------
            */

            if ($user->role === 'admin') {
                // Admin can view any order.
            }

            /*
            |--------------------------------------------------------------------------
            | DELIVERY PERSONNEL
            |--------------------------------------------------------------------------
            */ elseif ($user->role === 'delivery') {

                if (
                    (int) $order->delivery_personnel_id
                    !==
                    (int) $user->id
                ) {

                    return response()->json([
                        'success' => false,
                        'message' => 'This order is not assigned to you.',
                    ], 403);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | CUSTOMER
            |--------------------------------------------------------------------------
            */ else {

                if (
                    (int) $order->user_id
                    !==
                    (int) $user->id
                ) {

                    return response()->json([
                        'success' => false,
                        'message' => 'Unauthorized.',
                    ], 403);
                }
            }

            /*
            |--------------------------------------------------------------------------
            | LOAD RELATIONSHIPS
            |--------------------------------------------------------------------------
            */

            $order->load([
                'items.product',
                'user',
                'deliveryAddress',
                'deliveryPersonnel',
            ]);

            return response()->json([
                'success' => true,
                'data' => $order,
            ]);
        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Failed to load order.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE COD / NORMAL ORDER
    |--------------------------------------------------------------------------
    */

    public function store(Request $request)
    {
        return $this->createOrder(
            $request,
            false
        );
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE PAYMONGO ORDER
    |--------------------------------------------------------------------------
    */

    public function paymongo(Request $request)
    {
        return $this->createOrder(
            $request,
            true
        );
    }


    /*
    |--------------------------------------------------------------------------
    | CREATE ORDER
    |--------------------------------------------------------------------------
    */

    private function createOrder(
        Request $request,
        bool $usePayMongo
    ) {

        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([

            'customer_name' => [
                'required',
                'string',
                'max:191',
            ],

            'customer_contact' => [
                'required',
                'string',
                'max:191',
            ],

            'delivery_method' => [
                'required',
                'in:pickup,delivery',
            ],

            'payment_method' => [
                'required',
                'in:cod,paymongo,pay_at_counter',
            ],

            'delivery_address_id' => [
                'nullable',
                'integer',
                'exists:delivery_addresses,id',
            ],

            'customer_note' => [
                'nullable',
                'string',
            ],

            'items' => [
                'required',
                'array',
                'min:1',
            ],

            'items.*.product_id' => [
                'required',
                'integer',
                'exists:products,id',
            ],

            'items.*.quantity' => [
                'required',
                'numeric',
                'gt:0',
            ],
        ]);


        /*
        |--------------------------------------------------------------------------
        | LOGGED-IN USER
        |--------------------------------------------------------------------------
        */

        $user = $request->user();


        /*
        |--------------------------------------------------------------------------
        | PAYMENT / DELIVERY VALIDATION
        |--------------------------------------------------------------------------
        |
        | Pickup orders are paid at the counter.
        | Delivery orders may use COD or PayMongo.
        |
        */

        if (
            $validated['delivery_method'] === 'pickup'
            && $validated['payment_method'] !== 'pay_at_counter'
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Pickup orders must use Pay at Counter.',
            ], 422);
        }

        if (
            $validated['delivery_method'] === 'delivery'
            && $validated['payment_method'] === 'pay_at_counter'
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Pay at Counter is only available for pickup orders.',
            ], 422);
        }

        if (
            $usePayMongo
            && $validated['payment_method'] !== 'paymongo'
        ) {
            return response()->json([
                'success' => false,
                'message' => 'This endpoint requires PayMongo payment.',
            ], 422);
        }

        if (
            !$usePayMongo
            && $validated['payment_method'] === 'paymongo'
        ) {
            return response()->json([
                'success' => false,
                'message' => 'PayMongo orders must use the PayMongo checkout endpoint.',
            ], 422);
        }


        /*
        |--------------------------------------------------------------------------
        | DELIVERY ADDRESS VALIDATION
        |--------------------------------------------------------------------------
        */

        if (
            $validated['delivery_method'] === 'delivery'
            &&
            empty($validated['delivery_address_id'])
        ) {

            return response()->json([
                'success' => false,
                'message' =>
                'Please select a delivery address.',
            ], 422);
        }


        /*
        |--------------------------------------------------------------------------
        | PICKUP
        |--------------------------------------------------------------------------
        |
        | Pickup does not need a delivery address.
        |
        */

        if (
            $validated['delivery_method'] === 'pickup'
        ) {

            $validated['delivery_address_id'] = null;
        }


        /*
        |--------------------------------------------------------------------------
        | VERIFY DELIVERY ADDRESS
        |--------------------------------------------------------------------------
        |
        | The address must belong to the currently
        | logged-in customer.
        |
        */

        $deliveryAddress = null;

        if (
            $validated['delivery_method'] === 'delivery'
        ) {

            $deliveryAddress = DeliveryAddress::where(
                'id',
                $validated['delivery_address_id']
            )
                ->where(
                    'user_id',
                    $user->id
                )
                ->first();

            if (!$deliveryAddress) {

                return response()->json([
                    'success' => false,
                    'message' =>
                    'The selected delivery address does not belong to your account.',
                ], 422);
            }
        }


        /*
        |--------------------------------------------------------------------------
        | DATABASE TRANSACTION
        |--------------------------------------------------------------------------
        */

        DB::beginTransaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | GENERATE ORDER NUMBER
            |--------------------------------------------------------------------------
            */

            do {

                $orderNumber =
                    'CRY-' .
                    now()->format('YmdHisv') .
                    '-' .
                    strtoupper(
                        Str::random(8)
                    );
            } while (
                Order::where(
                    'order_number',
                    $orderNumber
                )->exists()
            );


            /*
            |--------------------------------------------------------------------------
            | CALCULATE TOTAL
            |--------------------------------------------------------------------------
            */

            $totalAmount = 0;

            $preparedItems = [];


            foreach (
                $validated['items']
                as $item
            ) {

                /*
                |--------------------------------------------------------------------------
                | LOCK PRODUCT ROW
                |--------------------------------------------------------------------------
                */

                $product = Product::where(
                    'id',
                    $item['product_id']
                )
                    ->lockForUpdate()
                    ->first();


                if (!$product) {

                    throw new \Exception(
                        'Product not found.'
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | QUANTITY
                |--------------------------------------------------------------------------
                |
                | Quantity is kilograms.
                |
                */

                $quantity =
                    (float) $item['quantity'];


                if ($quantity <= 0) {

                    throw new \Exception(
                        "Invalid quantity for {$product->name}."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | AVAILABLE KILOGRAMS
                |--------------------------------------------------------------------------
                */

                $availableWeight =
                    (float)
                    $product->available_weight_kg;


                if (
                    $quantity >
                    $availableWeight
                ) {

                    throw new \Exception(
                        "Not enough stock for {$product->name}. " .
                            "Only {$availableWeight} kg available."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | PRICE PER KG
                |--------------------------------------------------------------------------
                */

                $unitPrice =
                    (float)
                    $product->price_per_kg;


                /*
                |--------------------------------------------------------------------------
                | SUBTOTAL
                |--------------------------------------------------------------------------
                */

                $subtotal =
                    $quantity *
                    $unitPrice;


                $totalAmount +=
                    $subtotal;


                $preparedItems[] = [

                    'product' =>
                    $product,

                    'quantity' =>
                    $quantity,

                    'unit_price' =>
                    $unitPrice,

                    'subtotal' =>
                    $subtotal,
                ];
            }


            /*
            |--------------------------------------------------------------------------
            | CREATE ORDER
            |--------------------------------------------------------------------------
            */

            $order = Order::create([

                'user_id' =>
                $user->id,

                'order_number' =>
                $orderNumber,

                'customer_name' =>
                $validated['customer_name'],

                'customer_contact' =>
                $validated['customer_contact'],

                'order_type' =>
                'online',

                'status' =>
                'pending',

                /*
                |--------------------------------------------------------------------------
                | DELIVERY
                |--------------------------------------------------------------------------
                */

                'delivery_method' =>
                $validated['delivery_method'],

                'delivery_address_id' =>
                $validated['delivery_address_id'],

                /*
                |--------------------------------------------------------------------------
                | DELIVERY ASSIGNMENT
                |--------------------------------------------------------------------------
                |
                | No delivery personnel is assigned
                | when the customer first creates
                | the order.
                |
                */

                'delivery_personnel_id' =>
                null,

                'delivery_status' =>
                $validated['delivery_method'] === 'delivery'
                    ? 'pending'
                    : null,

                'assigned_at' =>
                null,

                'delivered_at' =>
                null,

                'customer_note' =>
                $validated['customer_note'] ?? null,

                /*
                |--------------------------------------------------------------------------
                | PAYMENT
                |--------------------------------------------------------------------------
                */

                'payment_method' =>
                $validated['payment_method'],

                'payment_status' =>
                'pending',

                /*
                |--------------------------------------------------------------------------
                | TOTAL
                |--------------------------------------------------------------------------
                */

                'total_amount' =>
                round(
                    $totalAmount,
                    2
                ),
            ]);


            /*
            |--------------------------------------------------------------------------
            | CREATE ORDER ITEMS
            |--------------------------------------------------------------------------
            */

            foreach (
                $preparedItems
                as $prepared
            ) {

                $order->items()->create([

                    'product_id' =>
                    $prepared['product']->id,

                    /*
                    |--------------------------------------------------------------------------
                    | SELLING TYPE
                    |--------------------------------------------------------------------------
                    */

                    'selling_type' =>
                    'kilogram',

                    /*
                    |--------------------------------------------------------------------------
                    | QUANTITY
                    |--------------------------------------------------------------------------
                    */

                    'quantity' =>
                    $prepared['quantity'],

                    /*
                    |--------------------------------------------------------------------------
                    | PRICE
                    |--------------------------------------------------------------------------
                    */

                    'unit_price' =>
                    $prepared['unit_price'],

                    /*
                    |--------------------------------------------------------------------------
                    | SUBTOTAL
                    |--------------------------------------------------------------------------
                    */

                    'subtotal' =>
                    $prepared['subtotal'],
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | PAYMONGO
            |--------------------------------------------------------------------------
            */

            if ($usePayMongo) {

                $checkoutResponse =
                    $this->createPayMongoCheckout(
                        $order,
                        $preparedItems
                    );


                /*
                |--------------------------------------------------------------------------
                | SAVE CHECKOUT SESSION ID
                |--------------------------------------------------------------------------
                */

                $order->update([

                    'paymongo_checkout_id' =>
                    $checkoutResponse['id'],
                ]);


                DB::commit();


                return response()->json([

                    'success' =>
                    true,

                    'message' =>
                    'Order created. Redirecting to PayMongo.',

                    'data' => [

                        'order' =>
                        $order->load([
                            'items.product',
                            'deliveryAddress',
                            'deliveryPersonnel',
                        ]),

                        'checkout_url' =>
                        $checkoutResponse['checkout_url'],

                        'checkout_id' =>
                        $checkoutResponse['id'],
                    ],

                ], 201);
            }


            /*
            |--------------------------------------------------------------------------
            | NORMAL / PAY AT COUNTER ORDER
            |--------------------------------------------------------------------------
            */

            DB::commit();


            return response()->json([

                'success' =>
                true,

                'message' =>
                'Order created successfully.',

                'data' =>
                $order->load([
                    'items.product',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ]),

            ], 201);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([

                'success' =>
                false,

                'message' =>
                'Failed to create order.',

                'error' =>
                $e->getMessage(),

            ], 500);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | PAYMONGO CHECKOUT SESSION
    |--------------------------------------------------------------------------
    */

    private function createPayMongoCheckout(
        Order $order,
        array $preparedItems
    ): array {

        $lineItems = [];


        foreach (
            $preparedItems
            as $prepared
        ) {

            $product =
                $prepared['product'];

            $quantity =
                $prepared['quantity'];

            $unitPrice =
                (float) $prepared['unit_price'];

            $subtotal =
                (float) $prepared['subtotal'];


            /*
            |--------------------------------------------------------------------------
            | PAYMONGO AMOUNT
            |--------------------------------------------------------------------------
            |
            | PayMongo uses centavos.
            | The subtotal already contains: quantity × price per kg.
            |
            */

            $amountInCentavos =
                (int) round(
                    $subtotal * 100
                );


            $lineItems[] = [

                'name' =>
                $product->name .
                    ' (' .
                    $quantity .
                    ' kg)',

                'amount' =>
                $amountInCentavos,

                'currency' =>
                'PHP',

                /*
                |--------------------------------------------------------------------------
                | PayMongo quantity must be integer.
                |--------------------------------------------------------------------------
                */

                'quantity' =>
                1,

                'description' =>
                'Crayfish - ' .
                    number_format(
                        $quantity,
                        2
                    ) .
                    ' kg at ₱' .
                    number_format(
                        $unitPrice,
                        2
                    ) .
                    '/kg',
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | PAYMONGO SECRET KEY
        |--------------------------------------------------------------------------
        */

        $secretKey =
            env(
                'PAYMONGO_SECRET_KEY'
            );


        if (!$secretKey) {

            throw new \Exception(
                'PAYMONGO_SECRET_KEY is not configured.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | FRONTEND URL
        |--------------------------------------------------------------------------
        */

        $frontendUrl =
            rtrim(
                env(
                    'FRONTEND_URL',
                    'http://localhost:5173'
                ),
                '/'
            );


        /*
        |--------------------------------------------------------------------------
        | CREATE CHECKOUT SESSION
        |--------------------------------------------------------------------------
        */

        $response =
            Http::withBasicAuth(
                $secretKey,
                ''
            )
            ->acceptJson()
            ->asJson()
            /*
            |--------------------------------------------------------------
            | PAYMONGO CONNECTION STABILITY
            |--------------------------------------------------------------
            |
            | PayMongo can occasionally take longer to resolve/connect.
            | The previous request was failing after ~10 seconds with:
            |
            |   cURL error 28: Resolving timed out after 10006 ms
            |
            | Give DNS/connection establishment up to 20 seconds and the
            | complete request up to 45 seconds. Retry only connection
            | exceptions so normal PayMongo/API errors are not retried.
            |
            */
            ->connectTimeout(20)
            ->timeout(45)
            ->retry(2, 1500, function ($exception) {
                return $exception instanceof \Illuminate\Http\Client\ConnectionException;
            })
            ->post(
                'https://api.paymongo.com/v2/checkout_sessions',
                [

                    'data' => [

                        'attributes' => [

                            'line_items' =>
                            $lineItems,

                            /*
                                |--------------------------------------------------------------------------
                                | PAYMENT METHODS
                                |--------------------------------------------------------------------------
                                */

                            'payment_method_types' => [

                                'gcash',

                                'card',

                                'grab_pay',

                                'paymaya',
                            ],

                            /*
                                |--------------------------------------------------------------------------
                                | DESCRIPTION
                                |--------------------------------------------------------------------------
                                */

                            'description' =>
                            'CRAYTECH Order ' .
                                $order->order_number,

                            /*
                                |--------------------------------------------------------------------------
                                | REFERENCE NUMBER
                                |--------------------------------------------------------------------------
                                */

                            'reference_number' =>
                            $order->order_number,

                            /*
                                |--------------------------------------------------------------------------
                                | METADATA
                                |--------------------------------------------------------------------------
                                */

                            'metadata' => [

                                'order_id' =>
                                (string)
                                $order->id,

                                'order_number' =>
                                $order->order_number,

                                'delivery_address_id' =>
                                $order->delivery_address_id
                                    ? (string)
                                    $order->delivery_address_id
                                    : null,
                            ],

                            /*
                                |--------------------------------------------------------------------------
                                | DISPLAY OPTIONS
                                |--------------------------------------------------------------------------
                                */

                            'show_description' =>
                            true,

                            'show_line_items' =>
                            true,

                            'send_email_receipt' =>
                            false,

                            /*
                                |--------------------------------------------------------------------------
                                | SUCCESS URL
                                |--------------------------------------------------------------------------
                                */

                            'success_url' =>
                            $frontendUrl .
                                '/customer/payment-success' .
                                '?order=' .
                                urlencode(
                                    $order->order_number
                                ),

                            /*
                                |--------------------------------------------------------------------------
                                | CANCEL URL
                                |--------------------------------------------------------------------------
                                */

                            'cancel_url' =>
                            $frontendUrl .
                                '/customer/checkout' .
                                '?payment=cancelled',
                        ],
                    ],
                ]
            );


        /*
        |--------------------------------------------------------------------------
        | PAYMONGO ERROR
        |--------------------------------------------------------------------------
        */

        if (!$response->successful()) {

            throw new \Exception(
                'PayMongo error: ' .
                    $response->body()
            );
        }


        $json =
            $response->json();


        $checkoutData =
            $json['data'] ?? null;


        $checkoutId =
            $checkoutData['id'] ?? null;


        $attributes =
            $checkoutData['attributes'] ?? [];


        $checkoutUrl =
            $attributes['checkout_url'] ?? null;


        if (
            !$checkoutId ||
            !$checkoutUrl
        ) {

            throw new \Exception(
                'PayMongo did not return a checkout URL.'
            );
        }


        return [

            'id' =>
            $checkoutId,

            'checkout_url' =>
            $checkoutUrl,
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | ASSIGN DELIVERY PERSONNEL
    |--------------------------------------------------------------------------
    |
    | ADMIN ONLY
    |
    */

    public function assignDelivery(
        Request $request,
        Order $order
    ) {

        /*
        |--------------------------------------------------------------------------
        | ADMIN CHECK
        |--------------------------------------------------------------------------
        */

        if ($request->user()->role !== 'admin') {

            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }


        /*
        |--------------------------------------------------------------------------
        | DELIVERY ORDER CHECK
        |--------------------------------------------------------------------------
        */

        if ($order->delivery_method !== 'delivery') {

            return response()->json([
                'success' => false,
                'message' =>
                'This order is not a delivery order.',
            ], 422);
        }


        /*
        |--------------------------------------------------------------------------
        | VALIDATION
        |--------------------------------------------------------------------------
        |
        | The packed piece count is recorded per order item because each
        | product can belong to a different batch.
        |
        */

        $validated = $request->validate([

            'delivery_personnel_id' => [
                'required',
                'integer',
                'exists:users,id',
            ],

            'items' => [
                'nullable',
                'array',
            ],

            'items.*.order_item_id' => [
                'required_with:items',
                'integer',
                'exists:order_items,id',
            ],

            'items.*.packed_pieces' => [
                'required_with:items',
                'integer',
                'min:1',
            ],

        ]);


        /*
        |--------------------------------------------------------------------------
        | FIND ACTIVE DELIVERY PERSON
        |--------------------------------------------------------------------------
        */

        $deliveryPersonnel = User::where(
            'id',
            $validated['delivery_personnel_id']
        )
            ->where(
                'role',
                'delivery'
            )
            ->where(
                'is_active',
                true
            )
            ->first();


        if (!$deliveryPersonnel) {

            return response()->json([
                'success' => false,
                'message' =>
                'The selected delivery personnel is not active.',
            ], 422);
        }


        /*
        |--------------------------------------------------------------------------
        | INVENTORY + ASSIGNMENT TRANSACTION
        |--------------------------------------------------------------------------
        */

        try {

            DB::beginTransaction();

            $lockedOrder = Order::where(
                'id',
                $order->id
            )
                ->lockForUpdate()
                ->firstOrFail();

            $orderItems = $lockedOrder->items()
                ->get();

            if ($orderItems->isEmpty()) {
                throw new \Exception(
                    'This order has no items to prepare.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | CHECK WHETHER INVENTORY WAS ALREADY RECORDED
            |--------------------------------------------------------------------------
            */

            $inventoryAlreadyRecorded =
                $orderItems->every(
                    fn($item) =>
                    $item->packed_pieces !== null
                );


            /*
            |--------------------------------------------------------------------------
            | INVENTORY DEDUCTION
            |--------------------------------------------------------------------------
            |
            | Only deduct once. If the order is being reassigned to another
            | rider after preparation, inventory is not deducted again.
            |
            */

            if (!$inventoryAlreadyRecorded) {

                $submittedItems =
                    collect($validated['items'] ?? [])
                    ->keyBy('order_item_id');

                foreach ($orderItems as $orderItem) {

                    if (
                        $orderItem->packed_pieces !== null
                    ) {
                        throw new \Exception(
                            'Inventory preparation is incomplete. Please contact the administrator.'
                        );
                    }

                    $prepared =
                        $submittedItems->get($orderItem->id);

                    if (!$prepared) {
                        throw new \Exception(
                            "Please enter the packed piece count for all order items."
                        );
                    }

                    $packedPieces =
                        (int) $prepared['packed_pieces'];

                    if ($packedPieces <= 0) {
                        throw new \Exception(
                            "Packed pieces for {$orderItem->id} must be greater than zero."
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | LOCK PRODUCT
                    |--------------------------------------------------------------------------
                    */

                    $product = Product::where(
                        'id',
                        $orderItem->product_id
                    )
                        ->lockForUpdate()
                        ->first();

                    if (!$product) {
                        throw new \Exception(
                            "Product for order item {$orderItem->id} was not found."
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | LOCK LINKED BATCH
                    |--------------------------------------------------------------------------
                    */

                    if (!$product->batch_id) {
                        throw new \Exception(
                            "Product {$product->name} is not linked to a batch."
                        );
                    }

                    $batch = DB::table('batches')
                        ->where(
                            'id',
                            $product->batch_id
                        )
                        ->lockForUpdate()
                        ->first();

                    if (!$batch) {
                        throw new \Exception(
                            "The batch linked to {$product->name} was not found."
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | CHECK BATCH POPULATION
                    |--------------------------------------------------------------------------
                    */

                    $currentPopulation =
                        (int) $batch->current_population;

                    if ($packedPieces > $currentPopulation) {
                        throw new \Exception(
                            "Not enough crayfish in {$batch->batch_name}. " .
                                "Only {$currentPopulation} pieces remain in the batch."
                        );
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | CHECK PRODUCT KILOGRAM STOCK
                    |--------------------------------------------------------------------------
                    */

                    $orderedWeight =
                        (float) $orderItem->quantity;

                    if (
                        $orderItem->selling_type === 'kilogram'
                    ) {

                        $availableWeight =
                            (float) $product->available_weight_kg;

                        if ($orderedWeight > $availableWeight) {
                            throw new \Exception(
                                "Not enough {$product->name} weight stock. " .
                                    "Only " .
                                    number_format(
                                        $availableWeight,
                                        2
                                    ) .
                                    " kg remain."
                            );
                        }

                        $newAvailableWeight =
                            max(
                                0,
                                $availableWeight - $orderedWeight
                            );

                        $product->available_weight_kg =
                            $newAvailableWeight;

                        $product->is_available =
                            $newAvailableWeight > 0;

                        $product->save();
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | DEDUCT BATCH PIECES
                    |--------------------------------------------------------------------------
                    */

                    DB::table('batches')
                        ->where(
                            'id',
                            $batch->id
                        )
                        ->update([
                            'current_population' =>
                            $currentPopulation - $packedPieces,

                            'updated_at' =>
                            now(),
                        ]);


                    /*
                    |--------------------------------------------------------------------------
                    | SAVE PACKED PIECES
                    |--------------------------------------------------------------------------
                    */

                    DB::table('order_items')
                        ->where(
                            'id',
                            $orderItem->id
                        )
                        ->update([
                            'packed_pieces' =>
                            $packedPieces,

                            'updated_at' =>
                            now(),
                        ]);
                }
            }


            /*
            |--------------------------------------------------------------------------
            | ASSIGN DELIVERY PERSONNEL
            |--------------------------------------------------------------------------
            */

            $lockedOrder->update([

                'delivery_personnel_id' =>
                $deliveryPersonnel->id,

                'delivery_status' =>
                'assigned',

                'assigned_at' =>
                now(),

                'delivered_at' =>
                null,
            ]);

            DB::commit();


            return response()->json([

                'success' => true,

                'message' =>
                'Inventory updated and delivery personnel assigned successfully.',

                'data' =>
                $lockedOrder->fresh([
                    'items.product',
                    'user',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ]),

            ]);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([

                'success' => false,

                'message' =>
                'Failed to prepare order and assign delivery personnel.',

                'error' =>
                $e->getMessage(),

            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DELIVERY PERSONNEL ORDERS
    |--------------------------------------------------------------------------
    |
    | DELIVERY ACCOUNT ONLY
    |
    */

    /*
|--------------------------------------------------------------------------
| DELIVERY PERSONNEL ORDERS
|--------------------------------------------------------------------------
|
| DELIVERY ACCOUNT ONLY
|
*/

    public function deliveryOrders(
        Request $request
    ) {
        $user = $request->user();

        /*
    |--------------------------------------------------------------------------
    | DELIVERY ROLE CHECK
    |--------------------------------------------------------------------------
    */

        if ($user->role !== 'delivery') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }

        try {

            /*
        |--------------------------------------------------------------------------
        | HISTORY MODE
        |--------------------------------------------------------------------------
        |
        | Normal Delivery Dashboard:
        |
        |     /delivery/orders
        |
        | Shows active deliveries only.
        |
        | Delivery History:
        |
        |     /delivery/orders?history=1
        |
        | Shows completed/delivered orders too.
        |
        */

            $isHistory = $request->boolean('history');

            /*
        |--------------------------------------------------------------------------
        | BASE QUERY
        |--------------------------------------------------------------------------
        */

            $query = Order::with([
                'items.product',
                'user',
                'deliveryAddress',
                'deliveryPersonnel',
            ])
                ->where(
                    'delivery_personnel_id',
                    $user->id
                )
                ->where(
                    'delivery_method',
                    'delivery'
                );

            /*
        |--------------------------------------------------------------------------
        | ACTIVE DELIVERY DASHBOARD
        |--------------------------------------------------------------------------
        |
        | If this is NOT history mode, hide delivered orders.
        |
        */

            if (!$isHistory) {
                $query->whereNotIn(
                    'delivery_status',
                    [
                        'delivered',
                    ]
                );
            }

            /*
        |--------------------------------------------------------------------------
        | GET ORDERS
        |--------------------------------------------------------------------------
        */

            $orders = $query
                ->latest()
                ->get();

            /*
        |--------------------------------------------------------------------------
        | RESPONSE
        |--------------------------------------------------------------------------
        */

            return response()->json([
                'success' => true,
                'data' => $orders,
            ]);
        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'message' =>
                'Failed to load delivery orders.',
                'error' =>
                $e->getMessage(),
            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE DELIVERY STATUS
    |--------------------------------------------------------------------------
    |
    | DELIVERY PERSONNEL ONLY
    |
    */
    /*
|--------------------------------------------------------------------------
| UPDATE DELIVERY STATUS
|--------------------------------------------------------------------------
|
| DELIVERY PERSONNEL ONLY
|
*/

    public function updateDeliveryStatus(
        Request $request,
        Order $order
    ) {
        $user = $request->user();

        /*
    |--------------------------------------------------------------------------
    | DELIVERY ROLE CHECK
    |--------------------------------------------------------------------------
    */

        if ($user->role !== 'delivery') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }


        /*
    |--------------------------------------------------------------------------
    | ASSIGNMENT CHECK
    |--------------------------------------------------------------------------
    */

        if (
            (int) $order->delivery_personnel_id
            !==
            (int) $user->id
        ) {
            return response()->json([
                'success' => false,
                'message' => 'This order is not assigned to you.',
            ], 403);
        }


        /*
    |--------------------------------------------------------------------------
    | VALIDATION
    |--------------------------------------------------------------------------
    */

        $validated = $request->validate([

            'delivery_status' => [
                'required',
                'string',
                'in:assigned,out_for_delivery,delivered,failed',
            ],

            'delivery_proof_image' => [
                'nullable',
                'image',
                'mimes:jpg,jpeg,png,webp',
                'max:10240',
            ],

        ]);


        /*
    |--------------------------------------------------------------------------
    | UPDATE
    |--------------------------------------------------------------------------
    */

        try {

            $status = $validated['delivery_status'];

            $data = [
                'delivery_status' => $status,
            ];


            /*
        |--------------------------------------------------------------------------
        | OUT FOR DELIVERY
        |--------------------------------------------------------------------------
        */

            if ($status === 'out_for_delivery') {

                $data['status'] = 'confirmed';

                $data['delivered_at'] = null;
            }


            /*
        |--------------------------------------------------------------------------
        | DELIVERED
        |--------------------------------------------------------------------------
        */

            if ($status === 'delivered') {

                /*
            |--------------------------------------------------------------------------
            | REQUIRE PROOF PHOTO
            |--------------------------------------------------------------------------
            */

                if (!$request->hasFile('delivery_proof_image')) {

                    return response()->json([
                        'success' => false,
                        'message' => 'A proof-of-delivery photo is required.',
                    ], 422);
                }


                /*
            |--------------------------------------------------------------------------
            | STORE PROOF PHOTO
            |--------------------------------------------------------------------------
            */

                $path = $request
                    ->file('delivery_proof_image')
                    ->store(
                        'delivery-proofs',
                        'public'
                    );


                /*
            |--------------------------------------------------------------------------
            | SAVE PHOTO PATH
            |--------------------------------------------------------------------------
            */

                $data['delivery_proof_image'] = $path;


                /*
            |--------------------------------------------------------------------------
            | DELIVERY TIME
            |--------------------------------------------------------------------------
            */

                $data['delivered_at'] = now();


                /*
            |--------------------------------------------------------------------------
            | COMPLETE ORDER
            |--------------------------------------------------------------------------
            */

                $data['status'] = 'completed';
            }


            /*
        |--------------------------------------------------------------------------
        | NON-DELIVERED STATUS
        |--------------------------------------------------------------------------
        */

            if ($status !== 'delivered') {

                $data['delivered_at'] = null;
            }


            /*
        |--------------------------------------------------------------------------
        | SAVE ORDER
        |--------------------------------------------------------------------------
        */

            $order->update($data);


            /*
        |--------------------------------------------------------------------------
        | LOAD RELATIONSHIPS
        |--------------------------------------------------------------------------
        */

            $order->load([
                'items.product',
                'user',
                'deliveryAddress',
                'deliveryPersonnel',
            ]);


            /*
        |--------------------------------------------------------------------------
        | SUCCESS RESPONSE
        |--------------------------------------------------------------------------
        */

            return response()->json([
                'success' => true,
                'message' => 'Delivery status updated successfully.',
                'data' => $order,
            ]);
        } catch (\Throwable $e) {

            /*
        |--------------------------------------------------------------------------
        | ERROR RESPONSE
        |--------------------------------------------------------------------------
        */

            return response()->json([
                'success' => false,
                'message' => 'Failed to update delivery status.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE ORDER
    |--------------------------------------------------------------------------
    |
    | ADMIN ONLY
    |
    */

    public function update(
        Request $request,
        Order $order
    ) {

        /*
        |--------------------------------------------------------------------------
        | ADMIN CHECK
        |--------------------------------------------------------------------------
        */

        if ($request->user()->role !== 'admin') {

            return response()->json([
                'success' => false,
                'message' => 'Unauthorized.',
            ], 403);
        }


        $validated =
            $request->validate([

                'status' => [
                    'required',
                    'string',
                    'in:pending,confirmed,completed,cancelled',
                ],

            ]);


        try {

            $order->update([

                'status' =>
                $validated['status'],
            ]);


            return response()->json([

                'success' =>
                true,

                'message' =>
                'Order updated successfully.',

                'data' =>
                $order->fresh([
                    'items.product',
                    'deliveryAddress',
                    'deliveryPersonnel',
                ]),

            ]);
        } catch (\Throwable $e) {

            return response()->json([

                'success' =>
                false,

                'message' =>
                'Failed to update order.',

                'error' =>
                $e->getMessage(),

            ], 500);
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CANCEL ORDER
    |--------------------------------------------------------------------------
    */

    public function cancel(
        Request $request,
        Order $order
    ) {

        try {

            /*
            |--------------------------------------------------------------------------
            | AUTHORIZATION
            |--------------------------------------------------------------------------
            */

            $user = $request->user();

            if (
                $user->role !== 'admin'
                &&
                (int) $order->user_id !== (int) $user->id
            ) {

                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized.',
                ], 403);
            }


            /*
            |--------------------------------------------------------------------------
            | PAID / COMPLETED ORDERS
            |--------------------------------------------------------------------------
            */

            if ($order->payment_status === 'paid') {

                return response()->json([
                    'success' => false,
                    'message' => 'Paid orders cannot be cancelled here.',
                ], 422);
            }

            if (
                $order->status === 'completed'
                ||
                $order->delivery_status === 'delivered'
            ) {

                return response()->json([
                    'success' => false,
                    'message' => 'Completed or delivered orders cannot be cancelled.',
                ], 422);
            }


            /*
            |--------------------------------------------------------------------------
            | CANCEL + RESTORE INVENTORY
            |--------------------------------------------------------------------------
            */

            DB::beginTransaction();

            $lockedOrder = Order::where(
                'id',
                $order->id
            )
                ->lockForUpdate()
                ->firstOrFail();

            $orderItems = $lockedOrder->items()
                ->get();

            foreach ($orderItems as $orderItem) {

                if ($orderItem->packed_pieces === null) {
                    continue;
                }

                $packedPieces =
                    (int) $orderItem->packed_pieces;


                /*
                |--------------------------------------------------------------------------
                | LOCK PRODUCT
                |--------------------------------------------------------------------------
                */

                $product = Product::where(
                    'id',
                    $orderItem->product_id
                )
                    ->lockForUpdate()
                    ->first();

                if (!$product) {
                    throw new \Exception(
                        "Product for order item {$orderItem->id} was not found."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | RESTORE PRODUCT WEIGHT
                |--------------------------------------------------------------------------
                */

                if (
                    $orderItem->selling_type === 'kilogram'
                ) {

                    $restoredWeight =
                        (float) $product->available_weight_kg
                        +
                        (float) $orderItem->quantity;

                    $product->available_weight_kg =
                        $restoredWeight;

                    $product->is_available = true;

                    $product->save();
                }


                /*
                |--------------------------------------------------------------------------
                | RESTORE BATCH POPULATION
                |--------------------------------------------------------------------------
                */

                if ($product->batch_id) {

                    $batch = DB::table('batches')
                        ->where(
                            'id',
                            $product->batch_id
                        )
                        ->lockForUpdate()
                        ->first();

                    if (!$batch) {
                        throw new \Exception(
                            "The batch linked to {$product->name} was not found."
                        );
                    }

                    DB::table('batches')
                        ->where(
                            'id',
                            $batch->id
                        )
                        ->update([
                            'current_population' =>
                            (int) $batch->current_population
                                +
                                $packedPieces,

                            'updated_at' =>
                            now(),
                        ]);
                }


                /*
                |--------------------------------------------------------------------------
                | CLEAR PREPARATION RECORD
                |--------------------------------------------------------------------------
                */

                DB::table('order_items')
                    ->where(
                        'id',
                        $orderItem->id
                    )
                    ->update([
                        'packed_pieces' =>
                        null,

                        'updated_at' =>
                        now(),
                    ]);
            }


            /*
            |--------------------------------------------------------------------------
            | CANCEL ORDER
            |--------------------------------------------------------------------------
            */

            $lockedOrder->update([

                'status' =>
                'cancelled',

                'payment_status' =>
                'cancelled',

                'delivery_status' =>
                $lockedOrder->delivery_method === 'delivery'
                    ? 'failed'
                    : null,
            ]);

            DB::commit();


            return response()->json([

                'success' =>
                true,

                'message' =>
                'Order cancelled successfully and prepared inventory was restored.',

            ]);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([

                'success' =>
                false,

                'message' =>
                'Failed to cancel order.',

                'error' =>
                $e->getMessage(),

            ], 500);
        }
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * =====================================================
     * LOGIN
     * =====================================================
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => [
                'required',
                'email',
            ],

            'password' => [
                'required',
            ],
        ]);

        /*
         * Find user.
         */
        $user = User::where(
            'email',
            $request->email
        )->first();

        /*
         * User doesn't exist.
         */
        if (!$user) {
            throw ValidationException::withMessages([
                'email' => [
                    'The email or password is incorrect.',
                ],
            ]);
        }

        /*
         * Check password.
         */
        if (!Hash::check(
            $request->password,
            $user->password
        )) {
            throw ValidationException::withMessages([
                'email' => [
                    'The email or password is incorrect.',
                ],
            ]);
        }

        /*
         * Check account status.
         *
         * This is especially important for
         * delivery personnel.
         */
        if (!$user->is_active) {
            throw ValidationException::withMessages([
                'email' => [
                    'This account has been disabled. Please contact the administrator.',
                ],
            ]);
        }

        /*
         * Remove old tokens.
         */
        $user->tokens()->delete();

        /*
         * Create new Sanctum token.
         */
        $token = $user
            ->createToken('craytech-app')
            ->plainTextToken;

        /*
         * Return user information.
         */
        return response()->json([
            'success' => true,

            'message' => 'Login successful.',

            'token' => $token,

            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'mobile_number' => $user->mobile_number,
                'business_name' => $user->business_name,
                'role' => $user->role,
                'is_active' => $user->is_active,
            ],
        ]);
    }


    /**
     * =====================================================
     * REGISTER CUSTOMER
     * =====================================================
     *
     * Public registration ALWAYS creates a customer.
     *
     * Nobody can register themselves as admin or delivery.
     */
    public function register(Request $request)
    {
        $validated = $request->validate([
            'name' => [
                'required',
                'string',
                'max:255',
            ],

            'email' => [
                'required',
                'email',
                'max:255',
                'unique:users,email',
            ],

            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
            ],
        ]);

        /*
         * Always create CUSTOMER.
         */
        $user = User::create([
            'name' => $validated['name'],

            'email' => $validated['email'],

            'password' => Hash::make(
                $validated['password']
            ),

            'role' => 'customer',

            'is_active' => true,
        ]);

        /*
         * Create token.
         */
        $token = $user
            ->createToken('craytech-app')
            ->plainTextToken;

        return response()->json([
            'success' => true,

            'message' => 'Registration successful.',

            'token' => $token,

            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'mobile_number' => $user->mobile_number,
                'business_name' => $user->business_name,
                'role' => $user->role,
                'is_active' => $user->is_active,
            ],
        ], 201);
    }


    /**
     * =====================================================
     * CURRENT USER
     * =====================================================
     */
    public function user(Request $request)
    {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated.',
            ], 401);
        }

        return response()->json([
            'success' => true,

            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'mobile_number' => $user->mobile_number,
                'business_name' => $user->business_name,
                'role' => $user->role,
                'is_active' => $user->is_active,
            ],
        ]);
    }


    /**
     * =====================================================
     * LOGOUT
     * =====================================================
     */
    public function logout(Request $request)
    {
        $user = $request->user();

        if ($user) {
            $token = $user->currentAccessToken();

            if ($token) {
                $token->delete();
            }
        }

        return response()->json([
            'success' => true,
            'message' => 'Logged out successfully.',
        ]);
    }
}

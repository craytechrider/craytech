<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\BatchUpdate;
use App\Models\Area;
use App\Models\CrayfishType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BatchController extends Controller
{
    /**
     * Get all batches.
     */
    public function index()
    {
        try {
            $batches = Batch::with([
                'area.areaType',
                'crayfishType',
            ])
                ->latest()
                ->get();

            return response()->json([
                'success' => true,
                'data' => $batches,
            ]);
        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'message' => 'Failed to load batches.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * Create a new batch.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'batch_name' => 'required|string|max:255',
            'area_id' => 'required|exists:areas,id',
            'crayfish_type_id' => 'required|exists:crayfish_types,id',
            'initial_population' => 'required|integer|min:1',
            'date_added' => 'required|date',
        ]);

        try {

            DB::beginTransaction();

            $area = Area::findOrFail($validated['area_id']);

            /*
            |--------------------------------------------------------------------------
            | Check area
            |--------------------------------------------------------------------------
            */

            if (
                (int) $area->occupied === 1 &&
                $area->crayfish_type_id !== null &&
                (int) $area->crayfish_type_id !== (int) $validated['crayfish_type_id']
            ) {
                DB::rollBack();

                return response()->json([
                    'success' => false,
                    'message' => 'This area already contains another crayfish type.',
                ], 422);
            }

            /*
            |--------------------------------------------------------------------------
            | Check capacity
            |--------------------------------------------------------------------------
            */

            $newTotal = (int) $area->total_crayfish
                + (int) $validated['initial_population'];

            if ($newTotal > (int) $area->capacity) {
                DB::rollBack();

                return response()->json([
                    'success' => false,
                    'message' => 'The initial population exceeds the available area capacity.',
                ], 422);
            }

            /*
            |--------------------------------------------------------------------------
            | Create batch
            |--------------------------------------------------------------------------
            */

            $batch = Batch::create([
                'batch_name' => $validated['batch_name'],
                'area_id' => $validated['area_id'],
                'crayfish_type_id' => $validated['crayfish_type_id'],
                'initial_population' => $validated['initial_population'],
                'current_population' => $validated['initial_population'],
                'date_added' => $validated['date_added'],
            ]);

            /*
            |--------------------------------------------------------------------------
            | Update area
            |--------------------------------------------------------------------------
            */

            $area->update([
                'occupied' => 1,
                'crayfish_type_id' => $validated['crayfish_type_id'],
                'total_crayfish' => $newTotal,
            ]);

            /*
            |--------------------------------------------------------------------------
            | Create initial batch update
            |--------------------------------------------------------------------------
            */

            BatchUpdate::create([
                'batch_id' => $batch->id,
                'population' => $validated['initial_population'],
                'mortality_rate' => 0,
            ]);

            DB::commit();

            /*
            |--------------------------------------------------------------------------
            | Reload relationships
            |--------------------------------------------------------------------------
            */

            $batch->load([
                'area.areaType',
                'crayfishType',
                'updates',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Batch added successfully.',
                'data' => $batch,
            ], 201);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to create batch.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * Update batch population.
     */
    public function update(Request $request, Batch $batch)
    {
        $validated = $request->validate([
            'current_population' => 'required|integer|min:0',
        ]);

        try {

            DB::beginTransaction();

            $oldPopulation = (int) $batch->current_population;
            $newPopulation = (int) $validated['current_population'];

            /*
            |--------------------------------------------------------------------------
            | Prevent population above initial population
            |--------------------------------------------------------------------------
            */

            if ($newPopulation > (int) $batch->initial_population) {
                DB::rollBack();

                return response()->json([
                    'success' => false,
                    'message' => 'Current population cannot exceed the initial population.',
                ], 422);
            }

            /*
            |--------------------------------------------------------------------------
            | Calculate difference
            |--------------------------------------------------------------------------
            */

            $difference = $newPopulation - $oldPopulation;

            /*
            |--------------------------------------------------------------------------
            | Update batch
            |--------------------------------------------------------------------------
            */

            $batch->update([
                'current_population' => $newPopulation,
            ]);

            /*
            |--------------------------------------------------------------------------
            | Update area population
            |--------------------------------------------------------------------------
            */

            $area = $batch->area;

            $newAreaPopulation =
                (int) $area->total_crayfish + $difference;

            if ($newAreaPopulation < 0) {
                $newAreaPopulation = 0;
            }

            $area->update([
                'total_crayfish' => $newAreaPopulation,
                'occupied' => $newAreaPopulation > 0 ? 1 : 0,
            ]);

            /*
            |--------------------------------------------------------------------------
            | Calculate mortality
            |--------------------------------------------------------------------------
            */

            $mortality = 0;

            if ((int) $batch->initial_population > 0) {
                $mortality =
                    (
                        (
                            (int) $batch->initial_population
                            - $newPopulation
                        )
                        /
                        (int) $batch->initial_population
                    ) * 100;
            }

            /*
            |--------------------------------------------------------------------------
            | Create update history
            |--------------------------------------------------------------------------
            */

            BatchUpdate::create([
                'batch_id' => $batch->id,
                'population' => $newPopulation,
                'mortality_rate' => $mortality,
            ]);

            DB::commit();

            $batch->load([
                'area.areaType',
                'crayfishType',
                'updates',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Population updated successfully.',
                'data' => $batch,
            ]);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to update population.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }


    /**
     * Delete batch.
     */
    public function destroy(Batch $batch)
    {
        try {

            DB::beginTransaction();

            $area = $batch->area;

            $population = (int) $batch->current_population;

            $newAreaPopulation =
                max(
                    0,
                    (int) $area->total_crayfish - $population
                );

            /*
            |--------------------------------------------------------------------------
            | Update area
            |--------------------------------------------------------------------------
            */

            if ($newAreaPopulation <= 0) {

                $area->update([
                    'occupied' => 0,
                    'crayfish_type_id' => null,
                    'total_crayfish' => 0,
                ]);
            } else {

                $area->update([
                    'total_crayfish' => $newAreaPopulation,
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | Delete batch
            |--------------------------------------------------------------------------
            */

            $batch->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Batch deleted successfully.',
            ]);
        } catch (\Throwable $e) {

            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to delete batch.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}

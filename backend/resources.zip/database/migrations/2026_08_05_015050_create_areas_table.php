<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('areas', function (Blueprint $table) {

            $table->id();

            $table->string('name');

            $table->foreignId('area_type_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->integer('capacity');

            $table->boolean('occupied')->default(false);

            $table->foreignId('crayfish_type_id')
                ->nullable()
                ->constrained()
                ->nullOnDelete();

            $table->integer('total_crayfish')->default(0);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('areas');
    }
};
